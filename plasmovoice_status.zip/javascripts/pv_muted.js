var placeholder = "%plasmovoice_muted%";
var voice = PlaceholderAPI.static.setPlaceholders(BukkitPlayer, placeholder);

var checkVoice = function (voice) {
  return voice === "true" ? " &c🎙&f " : " &a🎙&f ";
};

checkVoice(voice);